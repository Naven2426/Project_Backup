package com.example.rescueagency;

public class Constant {
    public static final String[] LOGIN_TYPE= {"USER","ADMIN","AGENT"};
    public static final String SF_NAME="SF";
    public static final String SF_USERNAME="SF_USERNAME";
    public static final String SF_USERID="SF_USERID";
    public static final String SF_EMAIL="SF_EMAIL";
    public static final String SF_PHONE="SF_PHONE";
    public static final String SF_ADDRESS="SF_ADDRESS";
    public static final String SF_DOB="SF_DOB";
    public static final String SF_GENDER="SF_GENDER";
}
